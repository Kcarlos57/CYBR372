## Part 2: Chosen-Plaintext Attack (CPA) Security Demonstration

This directory contains the extended implementation of a Java program that demonstrates Chosen-Plaintext Attack (CPA) security using the Advanced Encryption Standard (AES) algorithm in Cipher Block Chaining (CBC) mode with PKCS5 padding.

### Code Files

- `FileEncryptor.java`: The main Java class that performs encryption and decryption operations with chosen-plaintext attack security.
- `Util.java`: A utility class containing methods for converting bytes to hexadecimal strings and performing Base64 encoding and decoding.

### How to Use

1. Compile the code by running the following command:

   ```sh
   javac FileEncryptor.java
   ```

2. Run the program with appropriate arguments to demonstrate CPA security.

   For encryption:
   ```sh
   java FileEncryptor enc <base64Key> <inputFile> <outputFile>
   ```

   For decryption:
   ```sh
   java FileEncryptor dec <base64Key> <inputFile> <outputFile>
   ```

### Design Considerations

- The program allows specifying the secret key as a Base64 string.
- During encryption, a randomly generated initialization vector (IV) is used and stored in a separate file.
- During decryption, the IV is read from the separate file to ensure consistent use.
- The code provides human-readable error messages and logging for understanding and debugging.

### Demonstration of CPA Security

- The program demonstrates CPA security by allowing successful decryption of previously encrypted files.
- The ciphertext is different each time due to the use of a randomly generated IV.

---