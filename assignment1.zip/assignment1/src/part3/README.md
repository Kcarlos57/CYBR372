# Part 3: Generating a Secret Key from a Password

This section of the program demonstrates how to generate a secret key from a password using a secure method, adding a layer of security to the encryption process. It implements password-based encryption with the recommended NIST approach of using salt, iteration, and hashing.

## Usage

To use this feature, follow these steps:

1. Open a terminal or command prompt.
2. Navigate to the directory containing the `FileEncryptor` class.
3. Compile the program using:
   ```sh
   javac FileEncryptor.java
   ```
### Encryption

Run the following command to encrypt a file using a password:
```shell
java FileEncryptor enc "your_password_here" input.txt encrypted.enc
```

Replace `"your_password_here"` with the password you want to use and `input.txt` with the name of the file you want to encrypt. The encrypted file will be saved as `encrypted.enc`.

### Decryption

Run the following command to decrypt a file using the same password:

```shell
java FileEncryptor dec "your_password_here" encrypted.enc decrypted.txt
```

Replace `"your_password_here"` with the same password you used for encryption and `encrypted.enc` with the name of the encrypted file. The decrypted file will be saved as `decrypted.txt`.

## Important Notes

- The program uses a constant salt value for generating the secret key from the password. This ensures consistent results across different program runs. The salt value is stored in the `SALT` array in the code.
- It's important to keep the salt value secure. In a real-world scenario, you would use a more robust method to securely store the salt.

## Conclusion

This part of the program showcases how to enhance security by generating a secret key from a password. It uses a salted and iterated approach to derive the key, making it more resistant to attacks.

---
