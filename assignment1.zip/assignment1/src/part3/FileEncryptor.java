package part3;

import javax.crypto.*;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.spec.InvalidKeySpecException;
import java.util.Base64;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.crypto.SecretKeyFactory;

public class FileEncryptor {
    private static final Logger LOG = Logger.getLogger(FileEncryptor.class.getSimpleName());

    private static final String ALGORITHM = "AES";
    private static final String CIPHER = "AES/CBC/PKCS5PADDING";
    private static final int ITERATIONS = 10000; // Number of PBKDF2 iterations
    private static final byte[] SALT = {
            0x01, 0x23, 0x45, 0x67, (byte) 0x89, (byte) 0xAB, (byte) 0xCD, (byte) 0xEF,
            (byte) 0xFE, (byte) 0xDC, (byte) 0xBA, (byte) 0x98, 0x76, 0x54, 0x32, 0x10
    };

    public static void main(String[] args) throws Exception {
        if (args.length < 4) {
            System.out.println("Usage: java FileEncryptor (enc/dec) <keyOrPassword> <inputFile> <outputFile>");
            return;
        }

        String operation = args[0];
        String keyOrPassword = args[1];
        String inputFile = args[2];
        String outputFile = args[3];

        SecretKey secretKey;

        if (keyOrPassword.length() > 24) {
            byte[] keyBytes = Util.decodeBase64(keyOrPassword);
            secretKey = new SecretKeySpec(keyBytes, ALGORITHM);
        } else {
            secretKey = generateKeyFromPassword(keyOrPassword, SALT);
        }

        if ("enc".equalsIgnoreCase(operation)) {
            SecureRandom sr = new SecureRandom();
            byte[] initVector = new byte[16];
            sr.nextBytes(initVector);
            IvParameterSpec iv = new IvParameterSpec(initVector);

            // Encrypt the data using the derived secret key and generated IV
            performEncryption(inputFile, outputFile, secretKey, iv);
        } else if ("dec".equalsIgnoreCase(operation)) {

            // Decrypt the data using the derived secret key and IV stored in a separate file

            System.out.println("Secret key: " + Util.bytesToHex(secretKey.getEncoded()));
            performDecryption(inputFile, outputFile, secretKey);
        } else {
            System.out.println("Unknown operation: " + operation);
        }
    }

    private static void performEncryption(String inputFile, String outputFile, SecretKey secretKey,
                                          IvParameterSpec iv) throws IOException, NoSuchPaddingException,
            NoSuchAlgorithmException, InvalidAlgorithmParameterException, InvalidKeyException {
        Cipher cipher = Cipher.getInstance(CIPHER);
        cipher.init(Cipher.ENCRYPT_MODE, secretKey, iv);

        try (InputStream fin = new FileInputStream(inputFile);
             OutputStream fout = new FileOutputStream(outputFile);
             CipherOutputStream cipherOut = new CipherOutputStream(fout, cipher)) {
            byte[] bytes = new byte[1024];
            int length;
            while ((length = fin.read(bytes)) != -1) {
                cipherOut.write(bytes, 0, length);
            }
            System.out.println("Encryption finished, saved at " + outputFile);
        }

        // Save IV to a separate file
        String ivHex = Util.bytesToHex(iv.getIV());
        Files.write(Path.of(outputFile + ".iv"), ivHex.getBytes(), StandardOpenOption.CREATE);

        System.out.println("Secret key: " + Util.bytesToHex(secretKey.getEncoded()));
        System.out.println("IV: " + Util.bytesToHex(iv.getIV()));
    }

    private static void performDecryption(String inputFile, String outputFile, SecretKey secretKey)
            throws IOException, NoSuchPaddingException, NoSuchAlgorithmException, InvalidAlgorithmParameterException,
            InvalidKeyException {

        // Read IV from the separate file
        String ivHex = Files.readString(Path.of(inputFile + ".iv"));
        IvParameterSpec iv = hexIV(ivHex);

        Cipher cipher = Cipher.getInstance(CIPHER);
        cipher.init(Cipher.DECRYPT_MODE, secretKey, iv);

        try (InputStream encryptedData = new FileInputStream(inputFile);
             CipherInputStream decryptStream = new CipherInputStream(encryptedData, cipher);
             OutputStream decryptedOut = new FileOutputStream(outputFile)) {
            byte[] bytes = new byte[1024];
            int length;
            while ((length = decryptStream.read(bytes)) != -1) {
                decryptedOut.write(bytes, 0, length);
            }
            System.out.println("Decryption complete, saved at " + outputFile);
        } catch (IOException ex) {
            Logger.getLogger(FileEncryptor.class.getName()).log(Level.SEVERE, "Unable to decrypt", ex);
        }
    }

    private static IvParameterSpec hexIV(String ivHex) {
        // Remove spaces from the hex string and split into pairs of hexadecimal digits
        String[] hexPairs = ivHex.split(" ");
        byte[] ivBytes = new byte[hexPairs.length];

        // Convert each pair of hexadecimal digits to a byte
        for (int i = 0; i < hexPairs.length; i++) {
            ivBytes[i] = (byte) Integer.parseInt(hexPairs[i], 16);
        }

        // Create an IvParameterSpec using the IV bytes
        return new IvParameterSpec(ivBytes);
    }

    private static SecretKey generateKeyFromPassword(String password, byte[] salt)
            throws NoSuchAlgorithmException, InvalidKeySpecException {
        char[] passwordChars = password.toCharArray();

        PBEKeySpec pbeKeySpec = new PBEKeySpec(passwordChars, salt, ITERATIONS, 256);
        SecretKeyFactory keyFactory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
        return new SecretKeySpec(keyFactory.generateSecret(pbeKeySpec).getEncoded(), ALGORITHM);
    }

}
