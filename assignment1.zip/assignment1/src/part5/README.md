# Part 5: Vulnerable random values generator

In this part of the assignment, we explore the impact of using a vulnerable random number generator on the security of our cryptosystem. We implement a vulnerable pseudo-random number generator (vPNG) and use it to generate the Initialization Vector (IV) for encryption in Part 1. We will also discuss potential improvements to enhance the security of our design.

## Vulnerable PNG Implementation (vPNG.java)

The `vPNG` class is designed to generate a sequence of byte values based on a provided seed. The class provides the `next()` function to generate the next value in the sequence. It is deterministic, which means that if two instances with the same seed generate the same sequence of `next()` calls, they will produce the same sequence of bytes.

## Demonstrate Impact:

To demonstrate the impact of using the vulnerable PNG for generating the IV, we perform the following steps:

1. Encrypt a sample plaintext file using AES encryption and the secure random generator for IV.
2. Encrypt the same plaintext file using the vulnerable PNG for IV generation.
3. Attempt to decrypt both encrypted files using the appropriate IV generation methods.

After comparing the decrypted outputs, we can observe any differences and analyze how the use of a vulnerable PNG affects the decryption process.

## Discuss Improvements:

While the vulnerable PNG implementation serves the purpose of demonstrating security vulnerabilities, it is crucial to discuss potential improvements that would enhance the security of the cryptosystem:

1. **Use Secure RNGs:** Replace the vulnerable PNG with a cryptographically secure random number generator (CSPRNG) for generating IVs. Secure RNGs ensure unpredictability and are resistant to various attacks.

2. **Initialization Vector Management:** Implement a mechanism to ensure unique IVs for each encryption operation. This prevents potential attacks that might arise from reusing IVs.

3. **Seed Management:** Securely manage the seed for the RNG. If an attacker gains access to the seed, they can predict the sequence of generated values. Use strong key management practices to protect the seed.

4. **Entropy Source:** Consider using physical entropy sources, such as hardware random number generators, to enhance the unpredictability of generated values.

## Conclusion:

By exploring the use of a vulnerable PNG and its impact on the cryptosystem's security, we gain insights into the significance of using secure randomness in cryptographic operations. Secure random number generation is a fundamental aspect of building robust and secure cryptographic systems, and implementing strong randomness practices is essential to thwart potential attacks.

---
