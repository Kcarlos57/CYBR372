package part5;

import java.util.Random;

public class vPNG {
    private final Random random;

    public vPNG(long seed) {
        random = new Random(seed);
    }

    public byte next() {
        return (byte) random.nextInt(256);
    }
}
