package part4;

import javax.crypto.*;
import javax.crypto.spec.*;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.security.*;
import java.security.spec.InvalidKeySpecException;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class FileEncryptor {
    private static final int ITERATIONS = 10000; // Number of PBKDF2 iterations

    private static final Logger LOG = Logger.getLogger(FileEncryptor.class.getSimpleName());

    private static final String CIPHER = "/CBC/PKCS5PADDING";
    private static final byte[] SALT = {
            0x01, 0x23, 0x45, 0x67, (byte) 0x89, (byte) 0xAB, (byte) 0xCD, (byte) 0xEF,
            (byte) 0xFE, (byte) 0xDC, (byte) 0xBA, (byte) 0x98, 0x76, 0x54, 0x32, 0x10
    };

    public static void main(String[] args) {
        if (args.length < 2) {
            System.out.println("Usage: java FileEncryptor enc|dec|info [options] inputfile outputfile");
            return;
        }

        String action = args[0];

        switch (action) {
            case "enc" -> {
                if (args.length < 5) {
                    System.out.println("Usage: java FileEncryptor enc algorithm keylength password inputfile outputfile");
                    return;
                }
                encryptFile(args[1], Integer.parseInt(args[2]), args[3], args[4], args[5]);
            }
            case "dec" -> {
                if (args.length < 4) {
                    System.out.println("Usage: java FileEncryptor dec password inputfile outputfile");
                    return;
                }
                decryptFile(args[1], args[2], args[3]);
            }
            case "info" -> {
                printMetadata(args[1]);
            }
            default -> System.out.println("Unknown action: " + action);
        }
    }

    private static void encryptFile(String algorithm, int keyLength, String password, String inputFile, String outputFile) {
        try {
            SecretKey secretKey = generateSecretKey(password, algorithm, keyLength);

            byte[] initVector = generateRandomIV();
            IvParameterSpec iv = new IvParameterSpec(initVector);
            Cipher cipher = Cipher.getInstance(algorithm + CIPHER);
            cipher.init(Cipher.ENCRYPT_MODE, secretKey, iv);

            try (InputStream inputStream = new FileInputStream(inputFile);
                 OutputStream outputStream = new FileOutputStream(outputFile)) {

                outputStream.write(algorithm.getBytes()); // Write algorithm to output file
                outputStream.write((" " + keyLength + "\n").getBytes()); // Write key length to output file
                outputStream.write(SALT); // Write salt to output file
                outputStream.write(iv.getIV()); // Write IV to output file

                byte[] buffer = new byte[1024];
                int bytesRead;
                while ((bytesRead = inputStream.read(buffer)) != -1) {
                    byte[] encryptedBytes = cipher.update(buffer, 0, bytesRead);
                    if (encryptedBytes != null) {
                        outputStream.write(encryptedBytes);
                    }
                }
                byte[] finalEncryptedBytes = cipher.doFinal();
                if (finalEncryptedBytes != null) {
                    outputStream.write(finalEncryptedBytes);
                }

                System.out.println("Encryption finished, saved at " + outputFile);
            } catch (IOException ex) {
                ex.printStackTrace();
            }


            // Save IV to a separate file
            String ivHex = Util.bytesToHex(iv.getIV());
            Files.write(Path.of(outputFile + ".iv"), ivHex.getBytes(), StandardOpenOption.CREATE);

            System.out.println("Secret key: " + Util.bytesToHex(secretKey.getEncoded()));
            System.out.println("IV: " + Util.bytesToHex(iv.getIV()));

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void decryptFile(String password, String inputFile, String outputFile) {
        try {
            try (InputStream inputStream = new FileInputStream(inputFile);
                 OutputStream outputStream = new FileOutputStream(outputFile)) {

                // Read algorithm and key length from the encrypted file
//                byte[] algorithmAndKeyLength = new byte[16];
                byte[] algorithmAndKeyLength = new byte[12];
                if (inputStream.read(algorithmAndKeyLength) != -1) {
                    String[] parts = new String(algorithmAndKeyLength).trim().split(" ");
                    String algorithm = parts[0];
                    String[] lines = parts[1].trim().split("\\r?\\n");
                    int keyLength = Integer.parseInt(lines[0]);

                    SecretKey secretKey = generateSecretKey(password, algorithm, keyLength);
                    // Read IV from the separate file
                    String ivHex = Files.readString(Path.of(inputFile + ".iv"));
                    IvParameterSpec iv = hexIV(ivHex);

//                    // Initialize cipher and secret key
                    inputStream.read(SALT);
                    inputStream.read(iv.getIV());

                    Cipher cipher = Cipher.getInstance(algorithm + CIPHER);
                    cipher.init(Cipher.DECRYPT_MODE, secretKey, iv);

                    System.out.println("Secret key: " + Util.bytesToHex(secretKey.getEncoded()));
                    System.out.println("IV: " + Util.bytesToHex(iv.getIV()));

                    byte[] buffer = new byte[1024];
                    int bytesRead;
                    while ((bytesRead = inputStream.read(buffer)) != -1) {
                        System.out.println(1);
                        byte[] decryptedBytes = cipher.update(buffer, 0, bytesRead);
                        if (decryptedBytes != null) {
                            outputStream.write(decryptedBytes);
                        }
                    }
//                    outputStream.flush();
//                    readAllLinesAndPrint(inputFile);
//                    byte[] finalDecryptedBytes = cipher.doFinal();
//                    if (finalDecryptedBytes != null) {
//                        outputStream.write(finalDecryptedBytes);
//                    }

                    System.out.println("Decryption complete, saved at " + outputFile);
                } else {
                    System.out.println("Unable to read algorithm and key length from the file.");
                }
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void readAllLinesAndPrint(String FILENAME) {
        try (BufferedReader br = new BufferedReader(new FileReader(FILENAME))) {
            String line;
            while ((line = br.readLine()) != null) {
                System.out.println(line);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void printMetadata(String inputFile) {
        try {
            try (BufferedReader reader = new BufferedReader(new FileReader(inputFile))) {
                String algorithmAndKeyLength = reader.readLine(); // Read algorithm and key length
                if (algorithmAndKeyLength != null) {
                    String[] parts = algorithmAndKeyLength.trim().split(" ");
                    String algorithm = parts[0];
                    int keyLength = Integer.parseInt(parts[1]);
                    System.out.println(algorithm + " " + keyLength);
                } else {
                    System.out.println("Unable to read algorithm and key length from the file.");
                }
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }



    private static SecretKey generateSecretKey(String password, String ALGORITHM, int keyLength)
            throws NoSuchAlgorithmException, InvalidKeySpecException {
        char[] passwordChars = password.toCharArray();

        PBEKeySpec pbeKeySpec = new PBEKeySpec(passwordChars, SALT, ITERATIONS, keyLength);
        SecretKeyFactory keyFactory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
        return new SecretKeySpec(keyFactory.generateSecret(pbeKeySpec).getEncoded(), ALGORITHM);
    }

    private static byte[] generateRandomIV() {
        SecureRandom sr = new SecureRandom();
        byte[] initVector = new byte[16];
        sr.nextBytes(initVector); // 16 bytes IV
        return initVector;
    }

    private static IvParameterSpec hexIV(String ivHex) {
        // Remove spaces from the hex string and split into pairs of hexadecimal digits
        String[] hexPairs = ivHex.split(" ");
        byte[] ivBytes = new byte[hexPairs.length];

        // Convert each pair of hexadecimal digits to a byte
        for (int i = 0; i < hexPairs.length; i++) {
            ivBytes[i] = (byte) Integer.parseInt(hexPairs[i], 16);
        }

        // Create an IvParameterSpec using the IV bytes
        return new IvParameterSpec(ivBytes);
    }
}
