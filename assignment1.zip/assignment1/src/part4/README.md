## Part 4: Designing for Changes in Recommended Key Length and Algorithms

In this part of the assignment, I extended the `FileEncryptor` program to allow users to specify the encryption algorithm (Blowfish or AES) and key length when encrypting a file. Additionally, I embedded metadata in the encrypted file to record the algorithm and key length used for encryption. The metadata is used during decryption to correctly select the algorithm and key length.

### Changes Made

1. Added new command-line options to `FileEncryptor`:
    - `enc algorithm keylength password inputfile outputfile` to encrypt a file with the specified algorithm, key length, and password.
    - `info inputfile` to print the metadata embedded in the encrypted file.

2. Modified the encryption process to accept user-specified algorithm and key length and embed metadata.
3. Modified the decryption process to read metadata from the encrypted file and use it for decryption.
4. Ensured that the first line of the encrypted file doesn't cause decryption errors by adjusting the decryption process.

### Usage Examples

1. Encrypt a file using AES 128-bit key length:
   ```shell
   java FileEncryptor enc AES 128 "my password" plaintext.txt ciphertext.enc
   ```

2. Decrypt a file using the stored metadata:
   ```shell
   java FileEncryptor dec "my password" ciphertext.enc plaintext.txt
   ```

3. Print the metadata from an encrypted file:
   ```shell
   java FileEncryptor info ciphertext.enc
   ```

### Note

The program ensures that the encrypted file contains the metadata required for decryption, allowing compatibility with future algorithm and key length changes.

---
