## Part 1: Symmetric Encryption and Decryption

This directory contains the implementation of a Java program that performs symmetric encryption and decryption using the Advanced Encryption Standard (AES) algorithm in Cipher Block Chaining (CBC) mode with PKCS5 padding.

### Code Files

- `FileEncryptor.java`: The main Java class that performs the encryption and decryption operations.
- `Util.java`: A utility class containing methods for converting bytes to hexadecimal strings and performing Base64 encoding and decoding.

### How to Use

1. Compile the code by running the following command:

   ```sh
   javac FileEncryptor.java
   ```

2. Run the program with appropriate arguments to perform encryption or decryption.

   For encryption:
   ```sh
   java FileEncryptor enc <inputFile> <outputFile>
   ```

   For decryption:
   ```sh
   java FileEncryptor dec ((base 64 encoded key)) ((base 64 IV)) <inputFile> <outputFile>
   ```

### Design Considerations

- The program generates a random secret key and initialization vector (IV) for encryption.
- Encryption and decryption use AES in CBC mode with PKCS5 padding.
- The IV plays the role of a salt to enhance security.
- The code provides human-readable error messages and logging to aid in understanding and debugging.

### Testing

- The program has been tested on various input files to ensure proper functionality.
- Test cases include different file sizes, content, and edge cases.

### Limitations

- The current implementation generates a new random secret key and IV for each encryption operation, which can make it difficult to demonstrate chosen-plaintext attack (CPA) security.

---