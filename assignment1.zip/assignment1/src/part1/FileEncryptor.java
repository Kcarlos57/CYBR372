package part1;

import javax.crypto.*;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.io.*;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Arrays;
import java.util.Base64;
import java.util.logging.Level;
import java.util.logging.Logger;

public class FileEncryptor {
    private static final Logger LOG = Logger.getLogger(FileEncryptor.class.getSimpleName());

    private static final String ALGORITHM = "AES";
    private static final String CIPHER = "AES/CBC/PKCS5PADDING";

    public static void main(String[] args) throws NoSuchAlgorithmException {
        if (args.length < 3) {
            System.out.println("Usage: java FileEncryptor enc inputFile outputFile");
            System.out.println("Usage: java FileEncryptor dec ((base 64 encoded key)) ((base 64 IV)) inputFile outputFile");
            return;
        }

        String operation = args[0];

        try {
            if ("enc".equals(operation)) {
                String inputFile = args[1];
                String outputFile = args[2];
                SecretKey secretKey = secretKey();
                IvParameterSpec iv = hexIV();
                performEncryption(inputFile, outputFile, secretKey, iv);
            } else if ("dec".equals(operation)) {
                String key = args[1];
                String hex = args[2];
                String inputFile = args[3];
                String outputFile = args[4];
                SecretKey secretKey = secretKey(key);
                IvParameterSpec iv = hexIV(hex);
                performDecryption(inputFile, outputFile, secretKey, iv);
            } else {
                System.out.println("Invalid operation. Use enc for encryption or dec for decryption.");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void performEncryption(String inputFile, String outputFile, SecretKey secretKey, IvParameterSpec iv) throws Exception {
        Cipher cipher = Cipher.getInstance(CIPHER);
        cipher.init(Cipher.ENCRYPT_MODE, secretKey, iv);

        try (InputStream fin = new FileInputStream(inputFile);
             OutputStream fout = new FileOutputStream(outputFile);
             CipherOutputStream cipherOut = new CipherOutputStream(fout, cipher)) {
            byte[] bytes = new byte[1024];
            int length;
            while ((length = fin.read(bytes)) != -1) {
                cipherOut.write(bytes, 0, length);
            }
            System.out.println("Encryption finished, saved at " + outputFile);
        }

        System.out.println("Secret key: " + Util.bytesToHex(secretKey.getEncoded()));
        System.out.println("IV: " + Util.bytesToHex(iv.getIV()));
    }

    private static void performDecryption(String inputFile, String outputFile, SecretKey secretKey, IvParameterSpec iv) throws Exception {
        // Read secret key and IV from user or command-line arguments
        Cipher cipher = Cipher.getInstance(CIPHER);
        cipher.init(Cipher.DECRYPT_MODE, secretKey, iv);

        try (InputStream encryptedData = new FileInputStream(inputFile);
             CipherInputStream decryptStream = new CipherInputStream(encryptedData, cipher);
             OutputStream decryptedOut = new FileOutputStream(outputFile)) {
            byte[] bytes = new byte[1024];
            int length;
            while ((length = decryptStream.read(bytes)) != -1) {
                decryptedOut.write(bytes, 0, length);
            }
            System.out.println("Decryption complete, saved at " + outputFile);
        } catch (IOException ex) {
            Logger.getLogger(FileEncryptor.class.getName()).log(Level.SEVERE, "Unable to decrypt", ex);
        }
    }

    private static SecretKey secretKey() throws NoSuchAlgorithmException {
        // Generate a random secret key
        KeyGenerator keyGen = KeyGenerator.getInstance(ALGORITHM);
        keyGen.init(256); // Use the desired key size

        return keyGen.generateKey();
    }

    private static SecretKey secretKey(String secretKeyHex) {
        // Remove spaces from the hex string and split into pairs of hexadecimal digits
        String[] hexPairs = secretKeyHex.split(" ");
        byte[] keyBytes = new byte[hexPairs.length];

        // Convert each pair of hexadecimal digits to a byte
        for (int i = 0; i < hexPairs.length; i++) {
            keyBytes[i] = (byte) Integer.parseInt(hexPairs[i], 16);
        }

        // Create a SecretKey using the key bytes
        return new SecretKeySpec(keyBytes, "AES");
    }

    private static IvParameterSpec hexIV() {
        // Generate a random IV
        SecureRandom random = new SecureRandom();
        byte[] ivBytes = new byte[16]; // 16 bytes IV for AES
        random.nextBytes(ivBytes);
        return new IvParameterSpec(ivBytes);
    }

    private static IvParameterSpec hexIV(String ivHex) {
        // Remove spaces from the hex string and split into pairs of hexadecimal digits
        String[] hexPairs = ivHex.split(" ");
        byte[] ivBytes = new byte[hexPairs.length];

        // Convert each pair of hexadecimal digits to a byte
        for (int i = 0; i < hexPairs.length; i++) {
            ivBytes[i] = (byte) Integer.parseInt(hexPairs[i], 16);
        }

        // Create an IvParameterSpec using the IV bytes
        return new IvParameterSpec(ivBytes);
    }
}
